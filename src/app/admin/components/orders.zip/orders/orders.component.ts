import { Component } from '@angular/core';
import { Orders } from '../../../models/orders';
import { AdminService } from '../../services/admin.service';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrl: './orders.component.scss',
})
export class OrdersComponent {
  checked = false;
  color!: 'primary';
  indeterminate = false;
  labelPosition: 'before' | 'after' = 'after';
  disabled = false;
  deliveryFilter = 'SameDay';

  orderList: Orders[] = [];
  deliveryFilter = new FormControl([]);
  filteredOrders: Orders[] = [];
  searchValue: any;

  constructor(private adminService: AdminService) {}

  ngOnInit() {
    this.getOrderList();
    this.deliveryFilter.valueChanges.subscribe((values) => {
      this.applyFilters(values);
    });
  }

  getOrderList() {
    this.adminService.orders(this.deliveryFilter).subscribe((data) => {
      this.orderList = data;
      this.filteredOrders = data;
    });
  }

  applyFilters(selectedFilters: any) {
    console.log('name', selectedFilters);
    if (selectedFilters.length === 0) {
      this.filteredOrders = this.orderList;
      return;
    }

    this.filteredOrders = this.orderList.filter((order) => {
      const deliveryDate = new Date(order.delivery_date);
      const today = new Date();
      const nextDay = new Date(today);
      nextDay.setDate(today.getDate() + 1);
      const nextWeek = new Date(today);
      nextWeek.setDate(today.getDate() + 7);

      if (
        selectedFilters.includes('sameDay') &&
        this.isSameDay(deliveryDate, today)
      ) {
        return true;
      }
      if (
        selectedFilters.includes('nextDay') &&
        this.isSameDay(deliveryDate, nextDay)
      ) {
        return true;
      }
      if (
        selectedFilters.includes('nextWeek') &&
        this.isSameDay(deliveryDate, nextWeek)
      ) {
        return true;
      }
      return false;
    });
  }

  isSameDay(date1: Date, date2: Date): boolean {
    return (
      date1.getFullYear() === date2.getFullYear() &&
      date1.getMonth() === date2.getMonth() &&
      date1.getDate() === date2.getDate()
    );
  }

  search() {
    if (this.searchValue != '') {
      this.orderList = this.orderList?.filter((data: any) => {
        return data.person_name
          .toLocaleLowerCase()
          .match(this.searchValue?.toLocaleLowerCase());
      });
    } else if (this.searchValue == '') {
      this.getOrderList();
    }
  }
  // filterValue: any;

  // Filter() {
  //   if (this.filterValue != '') {
  //     this.orderList = this.orderList?.filter((data: any) => {
  //       return data.delivery_Day
  //         .toLocaleLowerCase()
  //         .match(this.filterValue?.toLocaleLowerCase());
  //     });
  //   } else if (this.filterValue == '') {
  //     this.getOrderList();
  //   }
  // }
}
